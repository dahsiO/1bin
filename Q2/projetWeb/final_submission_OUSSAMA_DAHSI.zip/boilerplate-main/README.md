# MatchUp — Backend API

**BINV1053 - Projet web 2026**  
**Author:** Oussama Dahsi 1bin3
**Student ID:** 202401014

MatchUp is a RESTful backend API for managing team sports matches. It handles users, teams, fields, and games.

---

## Installation

```bash
npm install
```

## Running the server

```bash
# Development mode (auto-reload)
npm run dev

# Build TypeScript
npm run build

# Production mode
npm start
```

## Demo data

```bash
# Populate the database with demo data
npm run demo:seed

# Reset all data (delete + re-seed)
npm run demo:reset

# Clear all data
npm run demo:clear
```

> **Important:** always run `npm run demo:seed` before testing the API.

Demo credentials after seeding:

| Username | Password | Role     |
|----------|----------|----------|
| admin    | admin    | admin    |
| player   | player   | player   |
| trainer  | trainer  | trainer  |
| ref      | ref      | referee  |

---

