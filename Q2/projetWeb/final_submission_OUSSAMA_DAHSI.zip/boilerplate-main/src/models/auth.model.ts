import { Request } from 'express';
import { UserDBO } from './user.model';

export interface AuthenticatedRequest extends Request {
  user?: UserDBO;
}
