// ============================================================
// FIELD MODEL
// ============================================================

// ---- DBO (Database Business Object) ----
// Stored in data/fields.json
export interface FieldDBO {
  id:         number;
  name:       string;
  location:   string;
  created_at: string;   
  updated_at: string;   
}

// ---- DTO (Data Transfer Object) ----
// Full field info
export interface FieldDTO {
  id:        number;
  name:      string;
  location:  string;
  createdAt: string;   
  updatedAt: string;  
}

// Payload to create a new field (POST /fields)
export interface NewFieldDTO {
  name:     string;
  location: string;
}

// Payload to update a field (PUT /fields/:id)
export interface UpdateFieldDTO {
  id:       number;
  name:     string;
  location: string;
}
