// ============================================================
// TEAM MODEL
// ============================================================

import { UserShortDTO } from './user.model';

// Supported sport types (fixed list per requirements)
export enum ESportType {
  FOOTBALL   = 'football',
  VOLLEYBALL = 'volleyball',
  WATERPOLO  = 'waterpolo',
  HOCKEY     = 'hockey',
  TENNIS     = 'tennis',
  BASKETBALL = 'basketball',
}

// ---- DBO (Database Business Object) ----
// Stored in data/teams.json
export interface TeamDBO {
  id:          number;
  name:        string;
  description: string | null;
  sport_type:  ESportType;
  players:     number[];    // list of user IDs
  trainer_id:  number;      // user ID of the trainer
  created_at:  string;      
  updated_at:  string;      
}

// Short view — returned by GET /teams (no auth required)
export interface TeamShortDTO {
  id:        number;
  name:      string;
  sportType: ESportType;
}

// Standard view — raw IDs, returned by most endpoints
export interface TeamDTO {
  id:          number;
  name:        string;
  description: string | null;
  sportType:   ESportType;
  players:     number[];
  trainerId:   number;
  createdAt:   string;
  updatedAt:   string;
}

// Full view — players and trainer resolved to objects, returned by GET /teams/own
export interface TeamFullDTO {
  id:          number;
  name:        string;
  description: string | null;
  sportType:   ESportType;
  players:     UserShortDTO[];
  trainer:     UserShortDTO;
  createdAt:   string;
  updatedAt:   string;
}

// Payload to create a new team (POST /teams)
export interface NewTeamDTO {
  name:         string;
  sportType:    ESportType;
  description?: string;
}

// Payload to update a team (PUT /teams/:id)
export interface UpdateTeamDTO {
  id:           number;
  name?:        string;
  description?: string | null;
  sportType?:   ESportType;
  players:      number[];
  trainerId:    number;
}
