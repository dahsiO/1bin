// ============================================================
// USER MODEL
// ============================================================

// Roles available in the system
export enum ERole {
  ADMIN    = 'admin',
  PLAYER   = 'player',
  TRAINER  = 'trainer',
  REFEREE  = 'referee',
}

// Account statuses
export enum EUserStatus {
  ACTIVE   = 'active',
  INACTIVE = 'inactive',
}

// ---- DBO (Database Business Object) ----
export interface UserDBO {
  id:         number;
  email:      string;
  first_name: string;
  last_name:  string;
  username:   string;
  password:   string;       // bcrypt hash — never exposed in responses
  role:       ERole;
  status:     EUserStatus;
  created_at: string;       
  updated_at: string;       
}

// ---- DTO (Data Transfer Object) ----
// Full user info returned to admins / own profile — password is never included
export interface UserDTO {
  id:        number;
  email:     string;
  firstName: string;
  lastName:  string;
  username:  string;
  role:      ERole;
  status:    EUserStatus;
  createdAt: string;
  updatedAt: string;
}

// Short info returned to non-admin authenticated users
export interface UserShortDTO {
  id:        number;
  firstName: string;
  lastName:  string;
}

// Payload to create a new user (POST /users)
export interface NewUserDTO {
  email:     string;
  username:  string;
  password:  string;
  firstName: string;
  lastName:  string;
}

// Payload to update a user's own profile (PUT /users/:id)
export interface UpdateUserDTO {
  email?:     string;
  username?:  string;
  firstName?: string;
  lastName?:  string;
}

// Payload for login (POST /users/login)
export interface UserLoginDTO {
  username: string;
  password: string;
}
