// ============================================================
// GAME MODEL
// ============================================================

// Possible statuses for a game, in lifecycle order
export enum EGameStatus {
  CREATED   = 'created',
  SCHEDULED = 'scheduled',
  STARTED   = 'started',
  FINISHED  = 'finished',
  CANCELLED = 'cancelled',
}

// ---- DBO (Database Business Object) ----
// Stored in data/games.json
export interface GameDBO {
  id:             number;
  name:           string | null;
  status:         EGameStatus;
  home_team_id:   number | null;
  away_team_id:   number | null;
  home_score:     number;
  away_score:     number;
  referee_id:     number | null;
  field_id:       number | null;
  scheduled_date: string | null;  // ISO 8601
  created_at:     string;         // ISO 8601
  updated_at:     string;         // ISO 8601
}

// Short view — returned by GET /games (no auth required)
export interface GameShortDTO {
  id:            number;
  status:        EGameStatus;
  name:          string | null;
  fieldId:       number | null;
  homeTeamId:    number | null;
  awayTeamId:    number | null;
  scheduledDate: string | null;
}

// Full game info — returned by most endpoints
export interface GameDTO {
  id:            number;
  name:          string | null;
  status:        EGameStatus;
  homeTeamId:    number | null;
  awayTeamId:    number | null;
  homeScore:     number;
  awayScore:     number;
  refereeId:     number | null;
  fieldId:       number | null;
  scheduledDate: string | null;
  createdAt:     string;
  updatedAt:     string;
}

// Payload to create a new game — all fields optional (POST /games)
export interface NewGameDTO {
  name?:          string;
  fieldId?:       number;
  refereeId?:     number;
  homeTeamId?:    number;
  awayTeamId?:    number;
  scheduledDate?: string;
}

// Payload to update game details (PUT /games/:id)
export interface UpdateGameDTO {
  id:              number;
  name?:           string;
  fieldId?:        number | null;
  refereeId?:      number | null;
  homeTeamId?:     number | null;
  awayTeamId?:     number | null;
  scheduledDate?:  string | null;
}
