import { GameDBO, GameDTO, GameShortDTO, NewGameDTO, UpdateGameDTO, EGameStatus } from '../models/game.model';

export class GamesMapper {

  static toShortDTO(dbo: GameDBO): GameShortDTO {
    return {
      id:            dbo.id,
      status:        dbo.status,
      name:          dbo.name,
      fieldId:       dbo.field_id,
      homeTeamId:    dbo.home_team_id,
      awayTeamId:    dbo.away_team_id,
      scheduledDate: dbo.scheduled_date,
    };
  }

  static toDTO(dbo: GameDBO): GameDTO {
    return {
      id:            dbo.id,
      name:          dbo.name,
      status:        dbo.status,
      homeTeamId:    dbo.home_team_id,
      awayTeamId:    dbo.away_team_id,
      homeScore:     dbo.home_score,
      awayScore:     dbo.away_score,
      refereeId:     dbo.referee_id,
      fieldId:       dbo.field_id,
      scheduledDate: dbo.scheduled_date,
      createdAt:     dbo.created_at,
      updatedAt:     dbo.updated_at,
    };
  }

  static fromNewDTO(dto: NewGameDTO, refereeId: number | null, id: number, status: EGameStatus, now: string): GameDBO {
    return {
      id,
      name:           dto.name ?? null,
      status,
      home_team_id:   dto.homeTeamId   ?? null,
      away_team_id:   dto.awayTeamId   ?? null,
      home_score:     0,
      away_score:     0,
      referee_id:     refereeId,
      field_id:       dto.fieldId      ?? null,
      scheduled_date: dto.scheduledDate ?? null,
      created_at:     now,
      updated_at:     now,
    };
  }

  static fromUpdateDTO(dto: UpdateGameDTO, existing: GameDBO, newStatus: EGameStatus): GameDBO {
    return {
      ...existing,
      name:           dto.name          !== undefined ? dto.name          : existing.name,
      field_id:       dto.fieldId       !== undefined ? dto.fieldId       : existing.field_id,
      referee_id:     dto.refereeId     !== undefined ? dto.refereeId     : existing.referee_id,
      home_team_id:   dto.homeTeamId    !== undefined ? dto.homeTeamId    : existing.home_team_id,
      away_team_id:   dto.awayTeamId    !== undefined ? dto.awayTeamId    : existing.away_team_id,
      scheduled_date: dto.scheduledDate !== undefined ? dto.scheduledDate : existing.scheduled_date,
      status:         newStatus,
      updated_at:     new Date().toISOString(),
    };
  }
}
