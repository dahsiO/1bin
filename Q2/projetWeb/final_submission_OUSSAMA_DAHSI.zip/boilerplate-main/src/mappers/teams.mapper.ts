import { TeamDBO, TeamDTO, TeamShortDTO, TeamFullDTO, NewTeamDTO, UpdateTeamDTO } from '../models/team.model';
import { UserShortDTO } from '../models/user.model';
import { UsersService } from '../services/users.service';
import { UsersMapper } from './users.mapper';

export class TeamsMapper {

  static toShortDTO(dbo: TeamDBO): TeamShortDTO {
    return {
      id:        dbo.id,
      name:      dbo.name,
      sportType: dbo.sport_type,
    };
  }

  static toDTO(dbo: TeamDBO): TeamDTO {
    return {
      id:          dbo.id,
      name:        dbo.name,
      description: dbo.description,
      sportType:   dbo.sport_type,
      players:     dbo.players,
      trainerId:   dbo.trainer_id,
      createdAt:   dbo.created_at,
      updatedAt:   dbo.updated_at,
    };
  }

  static toFullDTO(dbo: TeamDBO): TeamFullDTO | null {
    const trainerDBO = UsersService.getUserShortById(dbo.trainer_id);
    if (!trainerDBO) return null;

    const players: UserShortDTO[] = [];
    for (const id of dbo.players) {
      const userDBO = UsersService.getUserShortById(id);
      if (userDBO !== null) {
        players.push(UsersMapper.toShortDTO(userDBO));
      }
    }

    return {
      id:          dbo.id,
      name:        dbo.name,
      description: dbo.description,
      sportType:   dbo.sport_type,
      players,
      trainer:     UsersMapper.toShortDTO(trainerDBO),
      createdAt:   dbo.created_at,
      updatedAt:   dbo.updated_at,
    };
  }

  static fromNewDTO(dto: NewTeamDTO, trainerId: number, id: number, now: string): TeamDBO {
    return {
      id,
      name:        dto.name,
      description: dto.description ?? null,
      sport_type:  dto.sportType,
      players:     [],
      trainer_id:  trainerId,
      created_at:  now,
      updated_at:  now,
    };
  }

  static fromUpdateDTO(dto: UpdateTeamDTO, existing: TeamDBO): TeamDBO {
    return {
      ...existing,
      name:        dto.name        ?? existing.name,
      description: dto.description !== undefined ? dto.description : existing.description,
      sport_type:  dto.sportType   ?? existing.sport_type,
      players:     dto.players,
      trainer_id:  dto.trainerId,
      updated_at:  new Date().toISOString(),
    };
  }
}
