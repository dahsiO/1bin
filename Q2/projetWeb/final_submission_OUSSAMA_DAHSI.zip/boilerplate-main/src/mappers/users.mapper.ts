import { UserDBO, UserDTO, UserShortDTO, NewUserDTO, UpdateUserDTO, ERole, EUserStatus } from '../models/user.model';

export class UsersMapper {

  static toDTO(dbo: UserDBO): UserDTO {
    return {
      id:        dbo.id,
      email:     dbo.email,
      firstName: dbo.first_name,
      lastName:  dbo.last_name,
      username:  dbo.username,
      role:      dbo.role,
      status:    dbo.status,
      createdAt: dbo.created_at,
      updatedAt: dbo.updated_at,
    };
  }

  static toShortDTO(dbo: UserDBO): UserShortDTO {
    return {
      id:        dbo.id,
      firstName: dbo.first_name,
      lastName:  dbo.last_name,
    };
  }

  static fromNewDTO(dto: NewUserDTO, id: number, hashedPassword: string, now: string): UserDBO {
    return {
      id,
      email:      dto.email,
      first_name: dto.firstName,
      last_name:  dto.lastName,
      username:   dto.username,
      password:   hashedPassword,
      role:       ERole.PLAYER,
      status:     EUserStatus.ACTIVE,
      created_at: now,
      updated_at: now,
    };
  }

  static fromUpdateDTO(dto: UpdateUserDTO, existing: UserDBO): UserDBO {
    return {
      ...existing,
      email:      dto.email     ?? existing.email,
      first_name: dto.firstName ?? existing.first_name,
      last_name:  dto.lastName  ?? existing.last_name,
      username:   dto.username  ?? existing.username,
      updated_at: new Date().toISOString(),
    };
  }
}
