import { FieldDBO, FieldDTO, NewFieldDTO, UpdateFieldDTO } from '../models/field.model';

export class FieldsMapper {

  static toDTO(dbo: FieldDBO): FieldDTO {
    return {
      id:        dbo.id,
      name:      dbo.name,
      location:  dbo.location,
      createdAt: dbo.created_at,
      updatedAt: dbo.updated_at,
    };
  }

  static fromNewDTO(dto: NewFieldDTO, id: number, now: string): FieldDBO {
    return {
      id,
      name:       dto.name,
      location:   dto.location,
      created_at: now,
      updated_at: now,
    };
  }

  static fromUpdateDTO(dto: UpdateFieldDTO, existing: FieldDBO): FieldDBO {
    return {
      ...existing,
      name:       dto.name,
      location:   dto.location,
      updated_at: new Date().toISOString(),
    };
  }
}
