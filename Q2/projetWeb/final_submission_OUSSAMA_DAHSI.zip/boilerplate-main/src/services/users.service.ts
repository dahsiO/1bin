import bcrypt from 'bcrypt';
import { FilesService } from './files.service';
import { LoggerService } from './logger.service';
import { UserDBO, NewUserDTO, UpdateUserDTO, ERole, EUserStatus } from '../models/user.model';
import { UsersMapper } from '../mappers/users.mapper';

const DB_PATH = 'data/users.json';
const SALT_ROUNDS = 10;

function nextId(users: UserDBO[]): number {
  if (users.length === 0) return 1;
  let max = 0;
  for (const user of users) {
    if (user.id > max) max = user.id;
  }
  return max + 1;
}

export class UsersService {

  static getAllUsers(): UserDBO[] {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    const result: UserDBO[] = [];
    for (const user of users) {
      if (user.status === EUserStatus.ACTIVE) {
        result.push(user);
      }
    }
    return result;
  }

  static getUserById(id: number): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    for (const user of users) {
      if (user.id === id && user.status === EUserStatus.ACTIVE) {
        return user;
      }
    }
    return null;
  }

  static getUserShortById(id: number): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    for (const user of users) {
      if (user.id === id && user.status === EUserStatus.ACTIVE) {
        return user;
      }
    }
    return null;
  }

  static getUserDBOById(id: number): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    for (const user of users) {
      if (user.id === id) {
        return user;
      }
    }
    return null;
  }

  static getUserDBOByUsername(username: string): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    for (const user of users) {
      if (user.username === username) {
        return user;
      }
    }
    return null;
  }

  static getUserDBOByEmail(email: string): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    for (const user of users) {
      if (user.email === email) {
        return user;
      }
    }
    return null;
  }

  static createUser(dto: NewUserDTO): UserDBO {
    const users = FilesService.readFile<UserDBO>(DB_PATH);

    if (!dto.email.includes('@') || !dto.email.includes('.')) {
      throw new Error('Invalid email format: must contain "@" and "."');
    }
    for (const user of users) {
      if (user.email === dto.email) {
        throw new Error('Email already in use');
      }
    }
    for (const user of users) {
      if (user.username === dto.username) {
        throw new Error('Username already in use');
      }
    }

    const newUser = UsersMapper.fromNewDTO(dto, nextId(users), bcrypt.hashSync(dto.password, SALT_ROUNDS), new Date().toISOString());
    FilesService.appendFile<UserDBO>(DB_PATH, [newUser]);
    LoggerService.info(`createUser: created user ${newUser.id} (${newUser.username})`);
    return newUser;
  }

  static updateUser(id: number, dto: UpdateUserDTO): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < users.length; i++) {
      if (users[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    if (dto.email && dto.email !== users[index].email) {
      if (!dto.email.includes('@') || !dto.email.includes('.')) {
        throw new Error('Invalid email format: must contain "@" and "."');
      }
      for (const user of users) {
        if (user.email === dto.email) {
          throw new Error('Email already in use');
        }
      }
    }
    if (dto.username && dto.username !== users[index].username) {
      for (const user of users) {
        if (user.username === dto.username) {
          throw new Error('Username already in use');
        }
      }
    }

    const updated = UsersMapper.fromUpdateDTO(dto, users[index]);
    users[index] = updated;
    FilesService.writeFile<UserDBO>(DB_PATH, users);
    LoggerService.info(`updateUser: updated user ${id}`);
    return updated;
  }

  static deleteUser(id: number): boolean {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < users.length; i++) {
      if (users[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return false;

    if (users[index].role === ERole.ADMIN) {
      throw new Error('Admin accounts cannot be deleted');
    }

    users[index].status = EUserStatus.INACTIVE;
    users[index].updated_at = new Date().toISOString();
    FilesService.writeFile<UserDBO>(DB_PATH, users);
    LoggerService.info(`deleteUser: soft-deleted user ${id}`);
    return true;
  }

  static reactivateUser(id: number): boolean {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < users.length; i++) {
      if (users[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return false;

    users[index].status = EUserStatus.ACTIVE;
    users[index].updated_at = new Date().toISOString();
    FilesService.writeFile<UserDBO>(DB_PATH, users);
    LoggerService.info(`reactivateUser: reactivated user ${id}`);
    return true;
  }

  static patchUserRole(id: number, role: ERole): UserDBO | null {
    const users = FilesService.readFile<UserDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < users.length; i++) {
      if (users[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    if (users[index].role !== ERole.PLAYER) {
      throw new Error('Role can only be changed if the user currently has the "player" role');
    }

    users[index].role = role;
    users[index].updated_at = new Date().toISOString();
    FilesService.writeFile<UserDBO>(DB_PATH, users);
    LoggerService.info(`patchUserRole: user ${id} role → ${role}`);
    return users[index];
  }
}
