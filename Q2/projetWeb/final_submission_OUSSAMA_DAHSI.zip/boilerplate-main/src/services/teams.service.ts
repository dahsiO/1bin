import { FilesService } from './files.service';
import { LoggerService } from './logger.service';
import { TeamDBO, NewTeamDTO, UpdateTeamDTO } from '../models/team.model';
import { ERole, EUserStatus } from '../models/user.model';
import { UsersService } from './users.service';
import { TeamsMapper } from '../mappers/teams.mapper';

const DB_PATH = 'data/teams.json';

function nextId(teams: TeamDBO[]): number {
  if (teams.length === 0) return 1;
  let max = 0;
  for (const team of teams) {
    if (team.id > max) max = team.id;
  }
  return max + 1;
}

function assertValidRoster(playerIds: number[], trainerId: number): void {
  const uniqueIds = new Set(playerIds);
  if (uniqueIds.size !== playerIds.length) {
    throw new Error('Players list cannot contain duplicate user IDs');
  }

  for (const playerId of playerIds) {
    const player = UsersService.getUserDBOById(playerId);
    if (!player || player.status !== EUserStatus.ACTIVE) {
      throw new Error(`Player ${playerId} does not exist or is inactive`);
    }
  }

  const trainer = UsersService.getUserDBOById(trainerId);
  if (!trainer || trainer.status !== EUserStatus.ACTIVE) {
    throw new Error(`Trainer ${trainerId} does not exist or is inactive`);
  }
  if (trainer.role !== ERole.TRAINER) {
    throw new Error(`User ${trainerId} is not a trainer`);
  }
}

export class TeamsService {

  static getAllTeams(): TeamDBO[] {
    return FilesService.readFile<TeamDBO>(DB_PATH);
  }

  static getTeamById(id: number): TeamDBO | null {
    const teams = FilesService.readFile<TeamDBO>(DB_PATH);
    for (const team of teams) {
      if (team.id === id) {
        return team;
      }
    }
    return null;
  }

  static getTeamsByUser(userId: number): TeamDBO[] {
    const teams = FilesService.readFile<TeamDBO>(DB_PATH);
    const result: TeamDBO[] = [];
    for (const team of teams) {
      let isPlayer = false;
      for (const playerId of team.players) {
        if (playerId === userId) {
          isPlayer = true;
          break;
        }
      }
      if (isPlayer || team.trainer_id === userId) {
        result.push(team);
      }
    }
    return result;
  }

  static createTeam(dto: NewTeamDTO, trainerId: number): TeamDBO {
    const teams = FilesService.readFile<TeamDBO>(DB_PATH);
    for (const team of teams) {
      if (team.name === dto.name) {
        throw new Error(`Team name "${dto.name}" is already taken`);
      }
    }
    assertValidRoster([], trainerId);
    const newTeam = TeamsMapper.fromNewDTO(dto, trainerId, nextId(teams), new Date().toISOString());
    FilesService.appendFile<TeamDBO>(DB_PATH, [newTeam]);
    LoggerService.info(`createTeam: created team ${newTeam.id} (${newTeam.name})`);
    return newTeam;
  }

  static updateTeam(id: number, dto: UpdateTeamDTO): TeamDBO | null {
    const teams = FilesService.readFile<TeamDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < teams.length; i++) {
      if (teams[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    if (dto.name && dto.name !== teams[index].name) {
      for (const team of teams) {
        if (team.name === dto.name) {
          throw new Error(`Team name "${dto.name}" is already taken`);
        }
      }
    }
    assertValidRoster(dto.players, dto.trainerId);
    const updated = TeamsMapper.fromUpdateDTO(dto, teams[index]);
    teams[index] = updated;
    FilesService.writeFile<TeamDBO>(DB_PATH, teams);
    LoggerService.info(`updateTeam: updated team ${id}`);
    return updated;
  }

  static joinTeam(teamId: number, userId: number): TeamDBO | 'already_member' | null {
    const teams = FilesService.readFile<TeamDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < teams.length; i++) {
      if (teams[i].id === teamId) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    for (const playerId of teams[index].players) {
      if (playerId === userId) return 'already_member';
    }

    teams[index].players.push(userId);
    teams[index].updated_at = new Date().toISOString();
    FilesService.writeFile<TeamDBO>(DB_PATH, teams);
    LoggerService.info(`joinTeam: user ${userId} joined team ${teamId}`);
    return teams[index];
  }

  static leaveTeam(teamId: number, userId: number): TeamDBO | 'not_member' | null {
    const teams = FilesService.readFile<TeamDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < teams.length; i++) {
      if (teams[i].id === teamId) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    let isMember = false;
    for (const playerId of teams[index].players) {
      if (playerId === userId) {
        isMember = true;
        break;
      }
    }
    if (!isMember) return 'not_member';

    if (teams[index].trainer_id === userId) {
      throw new Error('The trainer of a team cannot leave it');
    }

    const newPlayers: number[] = [];
    for (const playerId of teams[index].players) {
      if (playerId !== userId) {
        newPlayers.push(playerId);
      }
    }
    teams[index].players = newPlayers;
    teams[index].updated_at = new Date().toISOString();
    FilesService.writeFile<TeamDBO>(DB_PATH, teams);
    LoggerService.info(`leaveTeam: user ${userId} left team ${teamId}`);
    return teams[index];
  }
}
