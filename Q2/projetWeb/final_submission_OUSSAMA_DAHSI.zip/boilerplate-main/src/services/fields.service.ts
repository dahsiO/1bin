import { FilesService } from './files.service';
import { LoggerService } from './logger.service';
import { FieldDBO, NewFieldDTO, UpdateFieldDTO } from '../models/field.model';
import { FieldsMapper } from '../mappers/fields.mapper';

const DB_PATH = 'data/fields.json';

function nextId(fields: FieldDBO[]): number {
  if (fields.length === 0) return 1;
  let max = 0;
  for (const field of fields) {
    if (field.id > max) max = field.id;
  }
  return max + 1;
}

export class FieldsService {

  static getAllFields(): FieldDBO[] {
    return FilesService.readFile<FieldDBO>(DB_PATH);
  }

  static getFieldById(id: number): FieldDBO | null {
    const fields = FilesService.readFile<FieldDBO>(DB_PATH);
    for (const field of fields) {
      if (field.id === id) {
        return field;
      }
    }
    return null;
  }

  static createField(dto: NewFieldDTO): FieldDBO {
    const fields = FilesService.readFile<FieldDBO>(DB_PATH);
    const now = new Date().toISOString();
    const newField = FieldsMapper.fromNewDTO(dto, nextId(fields), now);
    FilesService.appendFile<FieldDBO>(DB_PATH, [newField]);
    LoggerService.info(`createField: created field ${newField.id} (${newField.name})`);
    return newField;
  }

  static updateField(id: number, dto: UpdateFieldDTO): FieldDBO | null {
    const fields = FilesService.readFile<FieldDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < fields.length; i++) {
      if (fields[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    const updated = FieldsMapper.fromUpdateDTO(dto, fields[index]);
    fields[index] = updated;
    FilesService.writeFile<FieldDBO>(DB_PATH, fields);
    LoggerService.info(`updateField: updated field ${id}`);
    return updated;
  }
}
