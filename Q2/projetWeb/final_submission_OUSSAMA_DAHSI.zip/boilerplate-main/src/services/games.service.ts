import { FilesService } from './files.service';
import { LoggerService } from './logger.service';
import { GameDBO, NewGameDTO, UpdateGameDTO, EGameStatus } from '../models/game.model';
import { FieldDBO } from '../models/field.model';
import { GamesMapper } from '../mappers/games.mapper';
import { UsersService } from './users.service';
import { ERole } from '../models/user.model';

const DB_PATH     = 'data/games.json';
const FIELDS_PATH = 'data/fields.json';

function nextId(games: GameDBO[]): number {
  if (games.length === 0) return 1;
  let max = 0;
  for (const game of games) {
    if (game.id > max) max = game.id;
  }
  return max + 1;
}

function computeAutoStatus(fieldId: number | null | undefined, scheduledDate: string | null | undefined): EGameStatus {
  if (fieldId !== null && fieldId !== undefined && scheduledDate !== null && scheduledDate !== undefined) {
    return EGameStatus.SCHEDULED;
  }
  return EGameStatus.CREATED;
}

function assertFieldExists(fieldId: number): void {
  const fields = FilesService.readFile<FieldDBO>(FIELDS_PATH);
  let found = false;
  for (const field of fields) {
    if (field.id === fieldId) {
      found = true;
      break;
    }
  }
  if (!found) {
    throw new Error(`Field ${fieldId} does not exist`);
  }
}

function assertFieldAvailable(fieldId: number, scheduledDate: string, excludeGameId?: number): void {
  const games = FilesService.readFile<GameDBO>(DB_PATH);
  const targetDay = new Date(scheduledDate).toDateString();
  for (const game of games) {
    if (game.field_id === fieldId &&
        game.scheduled_date !== null &&
        new Date(game.scheduled_date).toDateString() === targetDay &&
        game.id !== excludeGameId &&
        game.status !== EGameStatus.CANCELLED) {
      throw new Error(`Field ${fieldId} is already booked on ${targetDay}`);
    }
  }
}

function assertValidReferee(refereeId: number): void {
  const user = UsersService.getUserDBOById(refereeId);
  if (!user || user.role !== ERole.REFEREE) {
    throw new Error(`User ${refereeId} is not a valid referee`);
  }
}


export class GamesService {

  static getAllUpcomingGames(): GameDBO[] {
    const games = FilesService.readFile<GameDBO>(DB_PATH);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const result: GameDBO[] = [];
    for (const game of games) {
      if (game.status === EGameStatus.STARTED) {
        result.push(game);
      } else if (game.status !== EGameStatus.FINISHED && game.status !== EGameStatus.CANCELLED) {
        if (game.scheduled_date !== null && new Date(game.scheduled_date) >= today) {
          result.push(game);
        }
      }
    }
    return result;
  }

  static getGameById(id: number): GameDBO | null {
    const games = FilesService.readFile<GameDBO>(DB_PATH);
    for (const game of games) {
      if (game.id === id) {
        return game;
      }
    }
    return null;
  }

  static createGame(dto: NewGameDTO, defaultRefereeId: number): GameDBO {
    const games = FilesService.readFile<GameDBO>(DB_PATH);

    let refereeId: number;
    if (dto.refereeId !== undefined) {
      refereeId = dto.refereeId;
    } else {
      refereeId = defaultRefereeId;
    }
    assertValidReferee(refereeId);

    if (dto.fieldId !== null && dto.fieldId !== undefined) {
      assertFieldExists(dto.fieldId);
      if (dto.scheduledDate !== null && dto.scheduledDate !== undefined) {
        assertFieldAvailable(dto.fieldId, dto.scheduledDate);
      }
    }

    const status = computeAutoStatus(dto.fieldId, dto.scheduledDate);
    const now    = new Date().toISOString();
    const newGame = GamesMapper.fromNewDTO(dto, refereeId, nextId(games), status, now);

    FilesService.appendFile<GameDBO>(DB_PATH, [newGame]);
    let gameName = 'unnamed';
    if (newGame.name !== null) {
      gameName = newGame.name;
    }
    LoggerService.info(`createGame: created game ${newGame.id} (${gameName})`);
    return newGame;
  }

  static updateGame(id: number, dto: UpdateGameDTO): GameDBO | null {
    const games = FilesService.readFile<GameDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < games.length; i++) {
      if (games[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    const existing = games[index];

    if (existing.status === EGameStatus.FINISHED || existing.status === EGameStatus.CANCELLED) {
      throw new Error('Game cannot be updated: status is finished or cancelled');
    }

    if (existing.status === EGameStatus.STARTED) {
      if (dto.fieldId !== undefined || dto.refereeId !== undefined ||
          dto.homeTeamId !== undefined || dto.awayTeamId !== undefined) {
        throw new Error('Cannot change field, referee, or teams for a started game');
      }
    }

    let newFieldId: number | null;
    if (dto.fieldId !== undefined) {
      newFieldId = dto.fieldId;
    } else {
      newFieldId = existing.field_id;
    }

    let newScheduledDate: string | null;
    if (dto.scheduledDate !== undefined) {
      newScheduledDate = dto.scheduledDate;
    } else {
      newScheduledDate = existing.scheduled_date;
    }

    let newRefereeId: number | null;
    if (dto.refereeId !== undefined) {
      newRefereeId = dto.refereeId;
    } else {
      newRefereeId = existing.referee_id;
    }

    if (newRefereeId !== null) assertValidReferee(newRefereeId);

    if (newFieldId !== null) {
      assertFieldExists(newFieldId);
      if (newScheduledDate !== null && (newFieldId !== existing.field_id || newScheduledDate !== existing.scheduled_date)) {
        assertFieldAvailable(newFieldId, newScheduledDate, id);
      }
    }

    let newStatus = existing.status;
    if (newStatus === EGameStatus.CREATED && newFieldId !== null && newScheduledDate !== null) {
      newStatus = EGameStatus.SCHEDULED;
    }

    const updated = GamesMapper.fromUpdateDTO(dto, existing, newStatus);
    games[index] = updated;
    FilesService.writeFile<GameDBO>(DB_PATH, games);
    LoggerService.info(`updateGame: updated game ${id}`);
    return updated;
  }

  static deleteGame(id: number): boolean {
    const games = FilesService.readFile<GameDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < games.length; i++) {
      if (games[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return false;

    games.splice(index, 1);
    FilesService.writeFile<GameDBO>(DB_PATH, games);
    LoggerService.info(`deleteGame: deleted game ${id}`);
    return true;
  }

  static patchScore(id: number, home: number, away: number): GameDBO | null {
    const games = FilesService.readFile<GameDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < games.length; i++) {
      if (games[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    if (games[index].status !== EGameStatus.STARTED) {
      throw new Error('Score can only be updated for a started game');
    }
    if (home < 0 || away < 0) {
      throw new Error('Score values must be non-negative');
    }

    games[index].home_score = home;
    games[index].away_score = away;
    games[index].updated_at = new Date().toISOString();
    FilesService.writeFile<GameDBO>(DB_PATH, games);
    LoggerService.info(`patchScore: game ${id} score set to ${home}-${away}`);
    return games[index];
  }

  static patchStatus(id: number, newStatus: EGameStatus): GameDBO | null {
    const games = FilesService.readFile<GameDBO>(DB_PATH);
    let index = -1;
    for (let i = 0; i < games.length; i++) {
      if (games[i].id === id) {
        index = i;
        break;
      }
    }
    if (index === -1) return null;

    const current = games[index];

    if (current.status === EGameStatus.CREATED) {
      if (newStatus !== EGameStatus.CANCELLED) {
        throw new Error(`Invalid status transition: ${current.status} → ${newStatus}`);
      }
    } else if (current.status === EGameStatus.SCHEDULED) {
      if (newStatus !== EGameStatus.STARTED && newStatus !== EGameStatus.CANCELLED) {
        throw new Error(`Invalid status transition: ${current.status} → ${newStatus}`);
      }
    } else if (current.status === EGameStatus.STARTED) {
      if (newStatus !== EGameStatus.FINISHED) {
        throw new Error(`Invalid status transition: ${current.status} → ${newStatus}`);
      }
    } else {
      throw new Error(`Invalid status transition: ${current.status} → ${newStatus}`);
    }

    if (newStatus === EGameStatus.STARTED) {
      if (!current.field_id || !current.referee_id || !current.home_team_id || !current.away_team_id) {
        throw new Error('Game must have a field, referee, and two teams before it can be started');
      }
      if (current.home_score !== 0 || current.away_score !== 0) {
        throw new Error('Scores must be zero before a game can be started');
      }
    }

    games[index].status = newStatus;
    games[index].updated_at = new Date().toISOString();
    FilesService.writeFile<GameDBO>(DB_PATH, games);
    LoggerService.info(`patchStatus: game ${id} → ${newStatus}`);
    return games[index];
  }
}
