import { Response, NextFunction } from 'express';
import { validateFakeToken } from '../utils/auth';
import { UsersService } from './users.service';
import { ERole, EUserStatus } from '../models/user.model';
import { AuthenticatedRequest } from '../models/auth.model';

export class AuthService {

  /**
   * Middleware that validates the token and sets req.user.
   * Returns 401 if the token is missing, invalid, or the user is inactive.
   */
  static authorize(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const token = req.get('authorization');
    if (!token) {
      return res.sendStatus(401);
    }

    const username = validateFakeToken(token);
    if (!username) {
      return res.status(401).json({ message: 'Missing or invalid token' });
    }

    const user = UsersService.getUserDBOByUsername(username);
    if (!user || user.status === EUserStatus.INACTIVE) {
      return res.status(401).json({ message: 'Missing or invalid token' });
    }

    req.user = user;
    return next();
  }

  /**
   * Middleware that checks the caller is an admin.
   * Must be used after authorize(). Returns 403 if not admin.
   */
  static isAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const user = req.user;
    if (!user) return res.sendStatus(401);
    if (user.role !== ERole.ADMIN) return res.sendStatus(403);
    return next();
  }

  /**
   * Middleware that checks the caller is a trainer.
   * Must be used after authorize(). Returns 403 if not trainer.
   */
  static isTrainer(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const user = req.user;
    if (!user) return res.sendStatus(401);
    if (user.role !== ERole.TRAINER) return res.sendStatus(403);
    return next();
  }

  /**
   * Middleware that checks the caller is an admin or a referee.
   * Must be used after authorize(). Returns 401 if neither (matches Swagger spec).
   */
  static isAdminOrReferee(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const user = req.user;
    if (!user) return res.sendStatus(401);
    if (user.role !== ERole.ADMIN && user.role !== ERole.REFEREE) {
      return res.status(401).json({ message: 'Missing or invalid token, or caller is not admin/referee' });
    }
    return next();
  }

  /**
   * Middleware that checks the caller is a referee.
   * Must be used after authorize(). Returns 403 if not referee.
   */
  static isReferee(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const user = req.user;
    if (!user) return res.sendStatus(401);
    if (user.role !== ERole.REFEREE) return res.sendStatus(403);
    return next();
  }

  /**
   * Middleware that checks the caller is a referee, trainer, or admin.
   * Must be used after authorize(). Returns 401 if none of those roles (matches Swagger spec).
   */
  static isRefereeOrTrainerOrAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const user = req.user;
    if (!user) return res.sendStatus(401);
    const allowed = [ERole.REFEREE, ERole.TRAINER, ERole.ADMIN];
    if (!allowed.includes(user.role)) {
      return res.status(401).json({ message: 'Authenticated user does not have referee, trainer, or admin role' });
    }
    return next();
  }
}
