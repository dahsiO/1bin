import { Request, Response, Router } from 'express';
import bcrypt from 'bcrypt';
import { LoggerService } from '../services/logger.service';
import { UsersService } from '../services/users.service';
import { UsersMapper } from '../mappers/users.mapper';
import { isNewUserDTO, isUserLoginDTO, isUserRole } from '../utils/guards';
import { generateFakeToken } from '../utils/auth';
import { AuthService } from '../services/auth.service';
import { AuthenticatedRequest } from '../models/auth.model';
import { ERole } from '../models/user.model';

export const usersController = Router();

/**
 * POST /users/login
 * Public — returns token, username and role on success
 */
usersController.post('/login', (req: Request, res: Response) => {
  LoggerService.info('[POST] /users/login');

  if (!isUserLoginDTO(req.body)) {
    return res.status(400).json({ message: 'Missing or invalid fields: username and password are required' });
  }

  const { username, password } = req.body;
  const user = UsersService.getUserDBOByUsername(username);

  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }

  if (user.status === 'inactive') {
    return res.status(403).json({ message: 'Account is inactive' });
  }

  const token = generateFakeToken(user.username);
  LoggerService.info(`login: success for user ${user.id} (${user.username})`);
  return res.status(200).json({ token, username: user.username, role: user.role });
});

/**
 * POST /users
 * Public — create a new user (role=player, status=active by default)
 */
usersController.post('/', (req: Request, res: Response) => {
  LoggerService.info('[POST] /users');

  if (!isNewUserDTO(req.body)) {
    return res.status(400).json({ message: 'Missing or invalid fields: email, username, password, firstName and lastName are required' });
  }

  try {
    const created = UsersService.createUser(req.body);
    return res.status(201).json(UsersMapper.toDTO(created));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * GET /users
 * Auth required — admin gets UserDTO[], others get UserShortDTO[]. Inactive excluded.
 */
usersController.get('/', AuthService.authorize, (req: Request, res: Response) => {
  LoggerService.info('[GET] /users');
  const authenticatedReq = req as AuthenticatedRequest;
  const users = UsersService.getAllUsers();

  if (authenticatedReq.user!.role === ERole.ADMIN) {
    const result = [];
    for (const user of users) {
      result.push(UsersMapper.toDTO(user));
    }
    return res.status(200).json(result);
  }
  const result = [];
  for (const user of users) {
    result.push(UsersMapper.toShortDTO(user));
  }
  return res.status(200).json(result);
});

/**
 * GET /users/username/:username
 * Admin or referee only — find a user by username
 */
usersController.get('/username/:username', AuthService.authorize, AuthService.isAdminOrReferee, (req: Request, res: Response) => {
  const { username } = req.params;
  LoggerService.info(`[GET] /users/username/${username}`);

  const user = UsersService.getUserDBOByUsername(username);
  if (!user) {
    return res.status(404).json({ message: `User with username "${username}" not found` });
  }
  return res.status(200).json(UsersMapper.toDTO(user));
});

/**
 * GET /users/email/:email
 * Admin or referee only — find a user by email
 */
usersController.get('/email/:email', AuthService.authorize, AuthService.isAdminOrReferee, (req: Request, res: Response) => {
  const { email } = req.params;
  LoggerService.info(`[GET] /users/email/${email}`);

  const user = UsersService.getUserDBOByEmail(email);
  if (!user) {
    return res.status(404).json({ message: `User with email "${email}" not found` });
  }
  return res.status(200).json(UsersMapper.toDTO(user));
});

/**
 * GET /users/:id
 * Auth required — admin or own profile returns UserDTO, others return UserShortDTO
 */
usersController.get('/:id', AuthService.authorize, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[GET] /users/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  const authenticatedReq = req as AuthenticatedRequest;
  const caller = authenticatedReq.user!;
  const user = UsersService.getUserById(id);

  if (!user) {
    return res.status(404).json({ message: `User ${id} not found` });
  }

  if (caller.role === ERole.ADMIN || caller.id === id) {
    return res.status(200).json(UsersMapper.toDTO(user));
  }
  return res.status(200).json(UsersMapper.toShortDTO(user));
});

/**
 * PUT /users/:id
 * Auth required — admin can update any user, non-admin only themselves.
 * Body must include an id matching the path param.
 */
usersController.put('/:id', AuthService.authorize, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PUT] /users/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  if (req.body.id === undefined || Number(req.body.id) !== id) {
    return res.status(400).json({ message: 'Body id must be present and match the path id' });
  }

  const authenticatedReq = req as AuthenticatedRequest;
  const caller = authenticatedReq.user!;
  if (caller.role !== ERole.ADMIN && caller.id !== id) {
    return res.status(403).json({ message: 'Forbidden: you can only update your own profile' });
  }

  try {
    const updated = UsersService.updateUser(id, req.body);
    if (!updated) {
      return res.status(404).json({ message: `User ${id} not found` });
    }
    return res.status(200).json(UsersMapper.toDTO(updated));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * DELETE /users/:id
 * Auth required — admin can soft-delete any user (except other admins).
 * Non-admin can only delete their own account.
 */
usersController.delete('/:id', AuthService.authorize, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[DELETE] /users/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  const authenticatedReq = req as AuthenticatedRequest;
  const caller = authenticatedReq.user!;
  if (caller.role !== ERole.ADMIN && caller.id !== id) {
    return res.status(403).json({ message: 'Forbidden: you can only delete your own account' });
  }

  try {
    const result = UsersService.deleteUser(id);
    if (!result) {
      return res.status(404).json({ message: `User ${id} not found` });
    }
    return res.status(200).json({ message: 'User deleted' });
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * PATCH /users/:id/role/:role
 * Admin only — change a user's role. Only users with role 'player' can be promoted.
 */
usersController.patch('/:id/role/:role', AuthService.authorize, AuthService.isAdmin, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const { role } = req.params;
  LoggerService.info(`[PATCH] /users/${id}/role/${role}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  if (!isUserRole(role)) {
    return res.status(400).json({ message: 'Invalid role value. Must be "admin", "player", "trainer" or "referee"' });
  }

  try {
    const updated = UsersService.patchUserRole(id, role as ERole);
    if (!updated) {
      return res.status(404).json({ message: `User ${id} not found` });
    }
    return res.status(200).json(UsersMapper.toDTO(updated));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * PATCH /users/:id/reactivate
 * Admin only — reactivate a previously soft-deleted user (status → active)
 */
usersController.patch('/:id/reactivate', AuthService.authorize, AuthService.isAdmin, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PATCH] /users/${id}/reactivate`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  const result = UsersService.reactivateUser(id);
  if (!result) {
    return res.status(404).json({ message: `User ${id} not found` });
  }
  return res.status(200).send();
});
