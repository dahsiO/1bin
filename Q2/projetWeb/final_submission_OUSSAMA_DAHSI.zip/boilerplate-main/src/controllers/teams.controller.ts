import { Request, Response, Router } from 'express';
import { LoggerService } from '../services/logger.service';
import { TeamsService } from '../services/teams.service';
import { TeamsMapper } from '../mappers/teams.mapper';
import { isNewTeamDTO, isUpdateTeamDTO } from '../utils/guards';
import { AuthService } from '../services/auth.service';
import { AuthenticatedRequest } from '../models/auth.model';

export const teamsController = Router();

/**
 * GET /teams
 * Public — returns TeamShortDTO[] (id, name, sportType only)
 */
teamsController.get('/', (req: Request, res: Response) => {
  LoggerService.info('[GET] /teams');
  const teams = TeamsService.getAllTeams();
  const result = [];
  for (const team of teams) {
    result.push(TeamsMapper.toShortDTO(team));
  }
  return res.status(200).json(result);
});

/**
 * GET /teams/own
 * Auth required — returns TeamFullDTO[] for teams where the user is a player or trainer
 */
teamsController.get('/own', AuthService.authorize, (req: Request, res: Response) => {
  LoggerService.info('[GET] /teams/own');
  // Express doesn't know that req has a .user field.
// We cast it to AuthenticatedRequest to tell TypeScript "trust me, .user is there".
// The ! means "I promise .user is not empty" — the auth middleware made sure of that.
  const userId = (req as AuthenticatedRequest).user!.id;
  const teams = TeamsService.getTeamsByUser(userId);
  const results = [];
  for (const team of teams) {
    const dto = TeamsMapper.toFullDTO(team);
    if (dto !== null) {
      results.push(dto);
    }
  }
  return res.status(200).json(results);
});

/**
 * GET /teams/:id
 * Public — returns TeamDTO for the given team
 */
teamsController.get('/:id', (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[GET] /teams/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid team ID' });
  }

  const team = TeamsService.getTeamById(id);
  if (!team) {
    return res.status(404).json({ message: `Team ${id} not found` });
  }
  return res.status(200).json(TeamsMapper.toDTO(team));
});

/**
 * POST /teams
 * Trainer only — creates a new team; trainerId is set automatically from the token
 */
teamsController.post('/', AuthService.authorize, AuthService.isTrainer, (req: Request, res: Response) => {
  LoggerService.info('[POST] /teams');
  const authenticatedReq = req as AuthenticatedRequest;

  if (!isNewTeamDTO(req.body)) {
    return res.status(400).json({ message: 'Missing or invalid fields: name and sportType are required' });
  }

  try {
    const team = TeamsService.createTeam(req.body, authenticatedReq.user!.id);
    return res.status(201).json(TeamsMapper.toDTO(team));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * PUT /teams/:id
 * Trainer only — replaces team fields; body id must match path id
 */
teamsController.put('/:id', AuthService.authorize, AuthService.isTrainer, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PUT] /teams/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid team ID' });
  }

  if (!isUpdateTeamDTO(req.body)) {
    return res.status(400).json({ message: 'Missing or invalid fields: id, players and trainerId are required' });
  }

  if (req.body.id !== id) {
    return res.status(400).json({ message: 'Body id must match the path id' });
  }

  try {
    const updated = TeamsService.updateTeam(id, req.body);
    if (!updated) {
      return res.status(404).json({ message: `Team ${id} not found` });
    }
    return res.status(200).json(TeamsMapper.toDTO(updated));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * PATCH /teams/:id/join
 * Auth required — adds the authenticated user to the team's player list
 */
teamsController.patch('/:id/join', AuthService.authorize, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PATCH] /teams/${id}/join`);
  const authenticatedReq = req as AuthenticatedRequest;

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid team ID' });
  }

  const result = TeamsService.joinTeam(id, authenticatedReq.user!.id);
  if (result === null) {
    return res.status(404).json({ message: `Team ${id} not found` });
  }
  if (result === 'already_member') {
    return res.status(400).json({ message: 'User is already a member of this team' });
  }
  return res.status(200).json(TeamsMapper.toDTO(result));
});

/**
 * PATCH /teams/:id/leave
 * Auth required — removes the authenticated user from the team's player list
 */
teamsController.patch('/:id/leave', AuthService.authorize, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PATCH] /teams/${id}/leave`);
  const authenticatedReq = req as AuthenticatedRequest;

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid team ID' });
  }

  try {
    const result = TeamsService.leaveTeam(id, authenticatedReq.user!.id);
    if (result === null || result === 'not_member') {
      return res.status(404).json({ message: `Team ${id} not found or user is not a member` });
    }
    return res.status(200).json(TeamsMapper.toDTO(result));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});
