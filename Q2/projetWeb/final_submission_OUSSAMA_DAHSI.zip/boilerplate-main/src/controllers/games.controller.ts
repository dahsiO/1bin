import { Request, Response, Router } from 'express';
import { LoggerService } from '../services/logger.service';
import { GamesService } from '../services/games.service';
import { GamesMapper } from '../mappers/games.mapper';
import { isNewGameDTO, isUpdateGameDTO, isEGameStatus } from '../utils/guards';
import { AuthService } from '../services/auth.service';
import { AuthenticatedRequest } from '../models/auth.model';

export const gamesController = Router();

/**
 * GET /games
 * Public — returns GameShortDTO[] for all upcoming and ongoing games
 */
gamesController.get('/', (req: Request, res: Response) => {
  LoggerService.info('[GET] /games');
  const games = GamesService.getAllUpcomingGames();
  const result = [];
  for (const game of games) {
    result.push(GamesMapper.toShortDTO(game));
  }
  return res.status(200).json(result);
});

/**
 * GET /games/:id
 * Public — returns the full GameDTO for a single game
 */
gamesController.get('/:id', (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[GET] /games/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid game ID' });
  }

  const game = GamesService.getGameById(id);
  if (!game) {
    return res.status(404).json({ message: `Game ${id} not found` });
  }
  return res.status(200).json(GamesMapper.toDTO(game));
});

/**
 * POST /games
 * Referee only — creates a new game; refereeId defaults to the authenticated user
 */
gamesController.post('/', AuthService.authorize, AuthService.isReferee, (req: Request, res: Response) => {
  LoggerService.info('[POST] /games');
  const authenticatedReq = req as AuthenticatedRequest;

  if (!isNewGameDTO(req.body)) {
    return res.status(400).json({ message: 'Invalid or missing fields' });
  }
 
  try {
    //if all good return 201
    const game = GamesService.createGame(req.body, authenticatedReq.user!.id);
    return res.status(201).json(GamesMapper.toDTO(game));
    //if service throws an error, catch it and return 400 with the error message
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * PUT /games/:id
 * Referee only — updates game fields; body id must match path id.
 * Locked for finished/cancelled games; started games cannot change field/referee/teams.
 */
gamesController.put('/:id', AuthService.authorize, AuthService.isReferee, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PUT] /games/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid game ID' });
  }

  if (!isUpdateGameDTO(req.body)) {
    return res.status(400).json({ message: 'Invalid or missing fields' });
  }

  if (req.body.id !== id) {
    return res.status(400).json({ message: 'Body id must match the path id' });
  }

  try {
    const updated = GamesService.updateGame(id, req.body);
    if (!updated) {
      return res.status(404).json({ message: `Game ${id} not found` });
    }
    return res.status(200).json(GamesMapper.toDTO(updated));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * DELETE /games/:id
 * Admin only — permanently removes a game (hard delete)
 */
gamesController.delete('/:id', AuthService.authorize, AuthService.isAdmin, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[DELETE] /games/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid game ID' });
  }

  const result = GamesService.deleteGame(id);
  if (!result) {
    return res.status(404).json({ message: `Game ${id} not found` });
  }
  return res.status(200).json({ message: 'Game deleted' });
});

/**
 * PATCH /games/:id/score/:home/:away
 * Referee only — sets the home and away score; game must be in started status
 */
gamesController.patch('/:id/score/:home/:away', AuthService.authorize, AuthService.isReferee, (req: Request, res: Response) => {
  const id   = Number(req.params.id);
  const home = Number(req.params.home);
  const away = Number(req.params.away);
  LoggerService.info(`[PATCH] /games/${id}/score/${home}/${away}`);

  if (isNaN(id) || isNaN(home) || isNaN(away)) {
    return res.status(400).json({ message: 'Invalid game ID or score values' });
  }

  try {
    const updated = GamesService.patchScore(id, home, away);
    if (!updated) {
      return res.status(400).json({ message: `Game ${id} not found` });
    }
    return res.status(200).json(GamesMapper.toDTO(updated));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});

/**
 * PATCH /games/:id/status/:status
 * Referee, trainer, or admin — transitions the game to the requested status.
 * Allowed: created→cancelled, scheduled→started|cancelled, started→finished
 */
gamesController.patch('/:id/status/:status', AuthService.authorize, AuthService.isRefereeOrTrainerOrAdmin, (req: Request, res: Response) => {
  const id     = Number(req.params.id);
  const status = req.params.status;
  LoggerService.info(`[PATCH] /games/${id}/status/${status}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid game ID' });
  }

  if (!isEGameStatus(status)) {
    return res.status(400).json({ message: `Invalid status value: ${status}` });
  }

  try {
    const updated = GamesService.patchStatus(id, status);
    if (!updated) {
      return res.status(404).json({ message: `Game ${id} not found` });
    }
    return res.status(200).json(GamesMapper.toDTO(updated));
  } catch (err) {
    if (err instanceof Error) {
      LoggerService.error(err);
      return res.status(400).json({ message: err.message });
    }
  }
});
