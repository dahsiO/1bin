import { Request, Response, Router } from 'express';
import bcrypt from 'bcrypt';
import { LoggerService } from '../services/logger.service';
import { UsersService } from '../services/users.service';
import { isUserLoginDTO } from '../utils/guards';
import { generateFakeToken } from '../utils/auth';

export const authController = Router();

/**
 * POST /auth/login
 * Public — returns token, username and role on success
 */
authController.post('/login', (req: Request, res: Response) => {
  LoggerService.info('[POST] /auth/login');

  if (!isUserLoginDTO(req.body)) {
    return res.status(400).json({ message: 'Missing or invalid fields: username and password are required' });
  }

  const { username, password } = req.body;
  const user = UsersService.getUserDBOByUsername(username);

  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }

  if (user.status === 'inactive') {
    return res.status(403).json({ message: 'Account is inactive' });
  }

  const token = generateFakeToken(user.username);
  LoggerService.info(`auth/login: success for user ${user.id} (${user.username})`);
  return res.status(200).json({ token, username: user.username, role: user.role });
});
