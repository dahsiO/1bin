import { Request, Response, Router } from 'express';
import { LoggerService } from '../services/logger.service';
import { FieldsService } from '../services/fields.service';
import { FieldsMapper } from '../mappers/fields.mapper';
import { isNewFieldDTO, isFieldDTO } from '../utils/guards';
import { AuthService } from '../services/auth.service';

export const fieldsController = Router();

/**
 * GET /fields
 * Public — returns FieldDTO[] for all fields
 */
fieldsController.get('/', (req: Request, res: Response) => {
  LoggerService.info('[GET] /fields');
  const fields = FieldsService.getAllFields();
  const result = [];
  for (const field of fields) {
    result.push(FieldsMapper.toDTO(field));
  }
  return res.status(200).json(result);
});

/**
 * GET /fields/:id
 * Public — returns the full FieldDTO for a single field
 */
fieldsController.get('/:id', (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[GET] /fields/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid field ID' });
  }
  //service will return null if not found, so we can handle both cases with one check
  const field = FieldsService.getFieldById(id);
  if (!field) { // if null, then not found
    return res.status(404).json({ message: `Field ${id} not found` });
  }
  return res.status(200).json(FieldsMapper.toDTO(field));
});

/**
 * POST /fields
 * Admin only — creates a new field; name and location are required
 */
fieldsController.post('/', AuthService.authorize, AuthService.isAdmin, (req: Request, res: Response) => {
  LoggerService.info('[POST] /fields');

  if (!isNewFieldDTO(req.body)) { // validate required fields and types(guards)  
    return res.status(400).json({ message: 'Invalid or missing fields' });
  }

  const field = FieldsService.createField(req.body); // service 
  return res.status(201).json(FieldsMapper.toDTO(field));
});

/**
 * PUT /fields/:id
 * Admin only — replaces name and location; body id must match path id
 */
fieldsController.put('/:id', AuthService.authorize, AuthService.isAdmin, (req: Request, res: Response) => {
  const id = Number(req.params.id);
  LoggerService.info(`[PUT] /fields/${id}`);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid field ID' });
  }

  if (!isFieldDTO(req.body)) {
    return res.status(400).json({ message: 'Invalid or missing fields' });
  }
  /**
      PUT /fields/3          ← id dans l'URL = 3
    Body: { "id": 99 }     ← id dans le body = 99  → 400 ❌

    PUT /fields/3
    Body: { "id": 3 }      ← id dans le body = 3   → OK ✅
    */

  if (req.body.id !== id) {
    return res.status(400).json({ message: 'Body id must match the path id' });
  }

  const updated = FieldsService.updateField(id, req.body);
  if (!updated) { //service returns null if not found, so we can handle both cases with one check
    return res.status(404).json({ message: `Field ${id} not found` });
  }
  return res.status(200).json(FieldsMapper.toDTO(updated));
});
