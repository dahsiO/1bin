public class Catalogue {

    private Article[] tableArticles;   //table des articles tous differents
    private int nombreArticles;


    /**
     * construit une table d'articles a partir de la table recue en parametre
     * on ne peut retrouver plusieurs fois un meme article
     * si l'article est present plusieurs fois dans la table recue,
     *       il ne sera retenu qu'une seule fois avec le prix le plus eleve
     * la taille physique de la table construite correspond a la taille physique de la table recue
     *       meme s'il y a des doublons
     * l'attribut nombreArticles doit correspondre au nombre d'articles differents retenus
     * @param tableRecue une table avec des articles pas necessairement tous differents
     * @throws IllegalArgumentException si la table recue est null ou vide ou contient des objets null
     */
    public Catalogue(Article[] tableRecue) {
        if (tableRecue == null)
            throw new IllegalArgumentException();

        if (tableRecue.length==0)
            throw new IllegalArgumentException();

        for (int i = 0; i < tableRecue.length; i++) {
            if (tableRecue[i] == null)
                throw new IllegalArgumentException();
        }


        tableArticles = new Article[tableRecue.length];
        //TODO

        //pour connaitre le numero d'un article,
        //utilisez la methode getNumeroArticle() de la classe Article

        //pour connaitre le prix d'un article,
        //utilisez la methode getPrix() de la classe Article

        //pour modifier le prix d'un article,
        //utilisez la methode setPrix() de la classe Article

        //CONTRAINTE : suivez l'algorithme propose dans l'enonce


    }


    public int getNombreArticles() {
        return nombreArticles;
    }


    /**
     * renvoie le prix d'un article
     * @param numeroArticle le numero de l'article recherche
     * @return le prix de l'article ou -1 si aucun article ne porte ce numero
     */
    public double donnerPrix(int numeroArticle){
        //TODO
        return 0;

        //pour connaitre le numero d'un article,
        //utilisez la methode getNumeroArticle() de la classe Article

        //pour connaitre le prix d'un article,
        //utilisez la methode getPrix() de la classe Article


    }


    /**
     * supprime un article
     * l'ordre des articles de la table doit etre conserve apres suppression
     * @param numeroArticle le numero de l'article a supprime
     * @return true si l'article etait bien present et a donc pu etre supprime, false sinon
     */
    public boolean supprimerArticle(int numeroArticle){
        //TODO
        return false;

        //pour connaitre le numero d'un article,
        //utilisez la methode getNumeroArticle() de la classe Article


    }


    /**
     * renvoie dans une table l'article le moins cher et l'article le plus cher
     * en cas d'ex-aequos (en terme de prix), on tiendra compte de l'ordre des articles, en prenant le 1er rencontre dans la table
     * La table renvoyee sera de dimension 0 s'il n'y a pas d'article
     * La table renvoyee sera de dimension 1 s'il n'y a qu'un seul article
     * Sinon, la table renvoyee sera de dimension 2 :
     *          on retrouve d'abord l'article le moins cher
     *          ensuite l'article le plus cher
     * La table pourrait contenir 2x le meme article, si tous les prix sont les memes
     * @return une table avec l'article le moins cher et l'article le plus cher
     */
    public Article[] minMax() {
        //TODO
        return null;

        //pour connaitre le prix d'un article,
        //utilisez la methode getPrix() de la classe Article


    }


    /**
     * calcule combien d'articles ont leur prix compris dans l'intervalle passe en parametre
     * les bornes de l'intervalle sont comprises
     * @param borneMin la borne min de l'intervalle
     * @param borneMax la borne max de l'intervalle
     * @return le nombre d'articles dans l'intervalle de prix
     * @throws IllegalArgumentException si borneMin>borneMax
     */
    public int nombreArticlesDansLIntervalle(double borneMin, double borneMax) {
        if (borneMin > borneMax)
            throw new IllegalArgumentException();
        //TODO
        return 0;

        //pour connaitre le prix d'un article,
        //utilisez la methode getPrix() de la classe Article


    }

    //A NE PAS MODIFIER
    //VA SERVIR POUR LES TESTS
    public Catalogue(){
    }
}
