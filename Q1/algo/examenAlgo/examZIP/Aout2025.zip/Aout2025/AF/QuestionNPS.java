import java.util.Arrays;
import java.util.NoSuchElementException;

public class QuestionNPS {
	
	private String question;
	private int[] tableReponses;


	/**
	 * Construit une question NPS
	 * D'une part, il y a une question
	 * D'autre part, il y a les reponses des clients
	 * Une reponse valide est represente par un entier compris entre 0 et 10
	 * La table des reponses (tableReponses) va contenir uniquement des reponses valides
	 * On y transfere les reponses valides de la table recue en parametre
	 * L'ordre des reponses doit etre le meme dans les 2 tables
	 * tableReponses doit etre entierement remplie
	 * (Sa taille phyqique doit correspondre au nombre de reponses valides transferees)
	 * Ex : tableRecue : [5, -1, 7, 6, 7, 7, 11, -5, 3]  --> tableReponses : [5, 7, 6, 7, 7, 3]
	 * @param question la question posee au client
	 * @param tableRecue une table de reponses qui ne sont pas obligatoirement toutes valides
	 * @throws IllegalArgumentException si la question est null ou si la table recue est null
	 */
	public QuestionNPS(String question, int[] tableRecue){

		if(question==null)
			throw new IllegalArgumentException();
		if(tableRecue==null)
			throw new IllegalArgumentException();

		this.question = question;

		//TODO

		//Pour connaitre la taille physique de tableReponses :
		//Pensez a faire un premier parcours de tableRecue pour connaitre le nombre de reponses valides

	}


	/**
	 * calcule la moyenne des reponses
	 * @return la moyenne
	 * @throws NoSuchElementException s'il n'y a pas de reponse
	 */
	public double moyenne(){

		if(tableReponses.length == 0)
			throw new NoSuchElementException();

		// TODO
		//La moyenne est un reel
		//Pour provoquer une division reelle, commencez le calcul par 1.0 * ...

		return 0;

	}


	/**
	 * recherche la mediane des reponses
	 * @return la mediane
	 * @throws NoSuchElementException s'il n'y a pas de reponse
	 */
	public int mediane(){

		if(tableReponses.length == 0)
			throw new NoSuchElementException();

		// TODO
		// CONTRAINTE : UTILISEZ L'ALGORITHME DECRIT DANS L'ENONCE

		return 0;
	}

	/**
	 * calcule le score NPS 
	 * @return le score NPS
	 * @throws NoSuchElementException s'il n'y a pas de reponse
	 */
	public double scoreNPS(){

		if(tableReponses.length == 0)
			throw new NoSuchElementException();

		// TODO

		// cfr enonce

		// Le score est un reel. Il s'agit d'un pourcentage.
		// Pour provoquer une division reelle, commencez le calcul par 100.0 * ...

		return 0;

	}


	// A NE PAS CHANGER
	// VA SERVIR POUR LES TESTS
	public QuestionNPS(int[] tableARecopier){
		this.question = " ";
		this.tableReponses = new int[tableARecopier.length];
		for (int i = 0; i < tableARecopier.length; i++) {
			tableReponses[i]=tableARecopier[i];
		}
	}

	// A NE PAS CHANGER
	// VA SERVIR POUR LES TESTS
	public String toString(){
		return Arrays.toString(tableReponses);
	}

}
