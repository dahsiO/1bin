import java.util.Arrays;


public class TableauDEntiers {
	public static final int TAILLE_PHYSIQUE = 50;
	int [] tab = new int[TAILLE_PHYSIQUE];
	int tailleLogique = 0;
	
	/**
	 * Ajoute un entier dans le tableau
	 * @param entier
	 * @return false si le tableau �tait d�j� plein, true sinon
	 */
	public boolean ajouter(int entier){
		if (tailleLogique == tab.length)
			return false;
		
		tab[tailleLogique] = entier;
		tailleLogique++;
		
		return true;
	}
	
	/**
	 * 
	 * @return le nombre d'�l�ments dans le tableau
	 */
	public int taille(){
		return tailleLogique;
	}
	
	/**
	 * 
	 * @param position
	 * @return Renvoie l'�l�ment � la position position du tableau
	 */
	public int getElement(int position){
		return tab[position];
	}
	
	@Override
	public String toString() {
		return "TableauDEntiers [tab=" + Arrays.toString(tab)
				+ ", tailleLogique=" + tailleLogique + "]";
	}
	
	Interval sommeExacteEntre(int somme){
		// C'est ici que �a se passe!
		// A compl�ter
		return null;
	}
	
	int [ ] supprimerIntervalSommeExacte(int somme){
		// C'est ici que �a se passe!
		// A compl�ter
		return null;
	}

	
}
